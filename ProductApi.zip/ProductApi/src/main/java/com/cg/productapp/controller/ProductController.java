package com.cg.productapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.productapp.bean.Product;
import com.cg.productapp.service.ProductService;

@RestController
public class ProductController {
	@Autowired
	ProductService productService;
	
	@RequestMapping(value="/api/product")
	public List<Product> getProduct(){
		return productService.getAllProducts();		
	}
	
	@RequestMapping("/api/product/{id}")
	public Product getProduct(@PathVariable int id){
		return productService.getProductById(id);
		
	}
	@RequestMapping(value="/api/product/{id}", method=RequestMethod.DELETE)
	public ResponseEntity<String> deleteEmployee(@PathVariable int id){
		productService.deleteProduct(id);
		return new ResponseEntity<String>("Product with the id "+id+"deleted",HttpStatus.OK);
	}

	@RequestMapping(value="/api/product", method=RequestMethod.POST)
	public ResponseEntity<String> addEmployee(@RequestBody Product product) {
		productService.addProduct(product);
		return new ResponseEntity<String>("Product added successfully",HttpStatus.OK);
		
	}
	
	@RequestMapping(value="/api/product/{id}",method=RequestMethod.PUT)
	public ResponseEntity<String> updateEmployee(@RequestBody Product product) {
		productService.updateProduct(product);
		return new ResponseEntity<String>("Product updated successfully",HttpStatus.OK);
		
	}
	
	@RequestMapping(value="/api/product/category")
	public List<Product> getProductByCategory(@RequestParam String category) {
		return productService.getProductByCategory(category);
	}
	
	@RequestMapping("/api/product/price")     
	public List<Product> getProductByPrice(@RequestParam int price1, int price2){         
		return productService.getProductByPrice(price1, price2);    
		}

}
