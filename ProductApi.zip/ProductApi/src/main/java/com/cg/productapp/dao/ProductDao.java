package com.cg.productapp.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.cg.productapp.bean.Product;

@Repository
public interface ProductDao extends JpaRepository<Product,Integer> {
	
	@Query("from Product where category=:cat")
	List<Product> getProductByCategory(@Param("cat") String category);
	
	@Query("from Product where price between :price1 and :price2")      
	List<Product> getProductByPrice(@Param("price1") int price1, @Param("price2") int price2);
}

