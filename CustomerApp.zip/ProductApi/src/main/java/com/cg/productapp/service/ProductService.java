package com.cg.productapp.service;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.cg.productapp.bean.Product;

public interface ProductService {
	List<Product> getAllProducts();
	Product getProductById(int id);
	void addProduct(Product product);
	void updateProduct(Product product);
	void deleteProduct(int id);
	List<Product> getProductByCategory(@Param("cat") String category);	
	List<Product> getProductByPrice(@Param("price1") int price1, @Param("price2") int price2);
}
