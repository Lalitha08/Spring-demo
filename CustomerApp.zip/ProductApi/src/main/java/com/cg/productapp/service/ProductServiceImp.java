package com.cg.productapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.productapp.bean.Product;
import com.cg.productapp.dao.ProductDao;

@Service
public class ProductServiceImp implements ProductService{

	@Autowired
	ProductDao productDao;
	@Override
	public List<Product> getAllProducts() {
		
		return productDao.findAll();
	}

	@Override
	public Product getProductById(int id) {		
		return productDao.findById(id).get();
	}


	@Override
	public void addProduct(Product product) {
		productDao.save(product);	
	}

	@Override
	public void updateProduct(Product product) {
		productDao.save(product);		
	}

	@Override
	public void deleteProduct(int id) {
		productDao.deleteById(id);
		
	}

	@Override
	public List<Product> getProductByCategory(String category) {
		return productDao.getProductByCategory(category);
	}

	@Override
	public List<Product> getProductByPrice(int price1, int price2) {
		return productDao.getProductByPrice(price1, price2);
	}
}
