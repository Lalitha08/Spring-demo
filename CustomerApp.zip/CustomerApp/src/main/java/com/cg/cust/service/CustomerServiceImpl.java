package com.cg.cust.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.cust.bean.Customer;
import com.cg.cust.dao.CustomerDao;
import com.cg.cust.exception.CustomerException;

@Service
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	CustomerDao customerDao;
	@Override
	public List<Customer> addCustomer(Customer cust) throws CustomerException {
		try {
		customerDao.save(cust);
		return customerDao.findAll();
		}
		catch(Exception e) {
			throw new CustomerException(e.getMessage());
		}
	}

	@Override
	public Customer getCustomerById(int id) throws CustomerException {	
		try {
		return customerDao.findById(id).get();
		}
		catch(Exception e) {
			throw new CustomerException(e.getMessage());
		}
	}

	@Override
	public void deleteCustomer(int id) throws CustomerException {		
		try {
			customerDao.deleteById(id);
		}
		catch(Exception e) {
			throw new CustomerException(e.getMessage());
		}
	}

	@Override
	public List<Customer> getAllCustomers() throws CustomerException {	
		try {
		return customerDao.findAll();
		}
		catch(Exception e) {
			throw new CustomerException(e.getMessage());
		}
	}

	@Override
	public List<Customer> getCustomerByCity(String city) throws CustomerException {	
		try {
		return customerDao.getCustomerByCity(city);
		}
		catch(Exception e) {
			throw new CustomerException(e.getMessage());
		}
	}

	@Override
	public List<Customer> updateCustomer(int id, Customer cust) throws CustomerException {
		try {
		Optional<Customer> optional=customerDao.findById(id);
		if(optional.isPresent()) {
			Customer customer=optional.get();
			customer.setType(cust.getType());
			customer.setCity(cust.getCity());
			customerDao.save(customer);
			return getAllCustomers();
		}
		else {
			throw new CustomerException("Customer with Id "+id+" does not exist");
		}
		
		}
		catch(Exception e) {
			throw new CustomerException(e.getMessage());
		}
	}

}
