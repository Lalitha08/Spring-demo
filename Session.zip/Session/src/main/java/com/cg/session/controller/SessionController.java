package com.cg.session.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.session.bean.Session;
import com.cg.session.exception.SessionException;
import com.cg.session.service.SessionService;

@RestController
public class SessionController {
	@Autowired
	SessionService sessionService;
	
	/*To create session table in the database */
	@RequestMapping(value="/createsession", method=RequestMethod.POST)
	public List<Session> createSession(@RequestBody Session session) throws SessionException{		
		return sessionService.createSession(session);		
	}
	
	/*To view all the sessions in the database*/
	@RequestMapping("/viewallsessions")	
	public List<Session> viewAllSessions() throws SessionException{
		return sessionService.viewAllSessions();
	}
	
	/**/
	@RequestMapping("/viewsession/{id}")
	public Session viewSessionById(@PathVariable int id) throws SessionException {
		return sessionService.viewSessionById(id);		
	}
	
	/*To delete the session*/
	@RequestMapping(value="/deletesession/{id}", method=RequestMethod.DELETE)
	public List<Session> deleteSession(@PathVariable int id) throws SessionException {
		return sessionService.deleteSession(id);		
	}
	
	/*To update the session*/
	@RequestMapping(value="/updatesession/{id}",method=RequestMethod.PUT)
	public List<Session> updateSession(@PathVariable int id,@RequestBody Session s) throws SessionException{
		return sessionService.updateSession(id, s);		
	}

}
