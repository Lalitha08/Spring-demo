package com.cg.session.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.session.bean.Session;
import com.cg.session.dao.SessionDao;
import com.cg.session.exception.SessionException;

@Service
public class SessionServiceImpl implements SessionService{
	
	@Autowired
	SessionDao sessionDao;
	
	/***
	 * Author: Birudukota Siva Lalitha
	 * Date of Creation: 30/07/2019
	 * Method Name: createSession
	 * Parameters: Passing the bean class
	 * Return Value: Displays all sessions including the added session
	 * Purpose: To create a new session
	 */

	@Override
	public List<Session> createSession(Session session) throws SessionException {
		try {
			sessionDao.save(session);
			return sessionDao.findAll();
			}
			catch(Exception e) {
				throw new SessionException("Invalid data");
			}
	}
	
	/***
	 * Author: Birudukota Siva Lalitha
	 * Date of Creation: 30/07/2019
	 * Method Name: viewAllSessions
	 * Return Value: Returns the list of all sessions
	 * Purpose: To display all sessions
	 */

	@Override
	public List<Session> viewAllSessions() throws SessionException {
		try {
			return sessionDao.findAll();
			}
			catch(Exception e) {
				throw new SessionException(e.getMessage());
			}
	}

	/***
	 * Author: Birudukota Siva Lalitha
	 * Date of Creation: 30/07/2019
	 * Method Name: viewSessionById
	 * Parameters: Passing the id
	 * Return Value: Return all the sessions
	 * Purpose: To display the requested session
	 */
	
	@Override
	public Session viewSessionById(int id) throws SessionException {
		try {
			return sessionDao.findById(id).get();
			}
			catch(Exception e) {
				throw new SessionException(e.getMessage());
			}
	}
	
	/***
	 * Author: Birudukota Siva Lalitha
	 * Date of Creation: 30/07/2019
	 * Method Name: deleteSession
	 * Parameters: Passing the id 
	 * Return Value: Return all the sessions
	 * Purpose: To delete the session of the passed id
	 */

	@Override
	public List<Session> deleteSession(int id) throws SessionException {
		try {
			sessionDao.deleteById(id);	
			return sessionDao.findAll();
			}
			catch(Exception e) {
				throw new SessionException(e.getMessage());
			}		
	}
	
	/***
	 * Author: Birudukota Siva Lalitha
	 * Date of Creation: 30/07/2019
	 * Method Name: updateSession
	 * Parameters: Passing id and bean class
	 * Return Value: Return all the sessions
	 * Purpose: To update the session. Updates only faculty and duration
	 */

	@Override
	public List<Session> updateSession(int id, Session s) throws SessionException {
		try {
			Optional<Session> optional = sessionDao.findById(id);
			if(optional.isPresent()) {
				Session session=optional.get();
				session.setFaculty(s.getFaculty());
				session.setDuration(s.getDuration());
				sessionDao.save(session);
				return viewAllSessions();
			}
			else
			{
				throw new SessionException("Session with Id "+id+" does not exist"); 
			}
		}
		catch(Exception e) {
			throw new SessionException("Invalid data");
		}
	}

}
