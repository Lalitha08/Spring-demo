package com.cg.session.bean;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Pattern;

@Entity
@Table(name="sessions") //Naming the table as sessions
public class Session {
	
	@Id
	@SequenceGenerator(name="sessionId", sequenceName="session_seq",allocationSize = 1)	//Generating sequence Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="sessionId")
	private Integer id;
	private String name;
	@Max(3)
	private Integer duration;
	private String faculty;
	@Column(name="modee")			//Changing the table column name as modee
	@Pattern(regexp="(ILT|VC)")		//mode validation
	private String mode;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getDuration() {
		return duration;
	}
	public void setDuration(Integer duration) {
		this.duration = duration;
	}
	public String getFaculty() {
		return faculty;
	}
	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String modee) {
		this.mode = modee;
	}
	@Override
	public String toString() {
		return "Session [id=" + id + ", name=" + name + ", duration=" + duration + ", faculty=" + faculty + ", mode="
				+ mode + "]";
	}
}