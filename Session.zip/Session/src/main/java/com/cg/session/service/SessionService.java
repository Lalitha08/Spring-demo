package com.cg.session.service;

import java.util.List;

import com.cg.session.bean.Session;
import com.cg.session.exception.SessionException;

public interface SessionService {
	public List<Session> createSession(Session session) throws SessionException;
	public List<Session> viewAllSessions() throws SessionException;
	public Session viewSessionById(int id) throws SessionException;
	public List<Session> deleteSession(int id) throws SessionException;
	public List<Session> updateSession(int id, Session s) throws SessionException;

}
