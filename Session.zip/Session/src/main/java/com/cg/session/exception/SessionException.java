package com.cg.session.exception;

/***
 * Author: Birudukota Siva Lalitha
 * Date of Creation: 30/07/2019
 * Class Name: SessionException
 * Purpose: For exception handling
 */
public class SessionException extends Exception {
	public SessionException() {
		super();
	}
	public SessionException(String msg) {
		super(msg);
	}

}
