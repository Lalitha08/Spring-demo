package com.cg.empapp.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.empapp.bean.Employee;
import com.cg.empapp.dao.EmployeeDao;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	@Autowired
	EmployeeDao employeeDao;

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return employeeDao.findAll();
	}

	@Override
	public Employee getEmployeeById(int id) {
		// TODO Auto-generated method stub
		return employeeDao.findById(id).get();
	}

	@Override
	public void updateEmployee(Employee emp) {
		employeeDao.save(emp);
		
	}

	@Override
	public void addEmployee(Employee emp) {
		employeeDao.save(emp);
		
	}

	@Override
	public void deleteEmployee(int id) {
		employeeDao.deleteById(id);
		
	}

	@Override
	public List<Employee> getEmployeeByGender(String gender) {
		// TODO Auto-generated method stub
		return employeeDao.getEmployeeByGender(gender);
	}

}
